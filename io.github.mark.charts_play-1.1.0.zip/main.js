var DZ = 'https://api.deezer.com';
var AU = 'https://api.audius.co/v1';
var APP = 'orpheon_charts_play';

function getJson(url) {
  try {
    var r = myspoti.http.get(url, { timeout: 8000 });
    if (!r.ok) return null;
    return r.json();
  } catch (e) {
    return null;
  }
}

function de() {
  return String(myspoti.locale || 'en').split('-')[0] === 'de';
}

function norm(s) {
  return String(s || '').toLowerCase().replace(/\(.*?\)|\[.*?\]/g, ' ').replace(/[^a-z0-9\u00c0-\uffff]+/g, ' ').replace(/\s+/g, ' ').trim();
}

function trackItems(list) {
  return (list || []).filter(function (t) { return t && t.id; }).slice(0, 50).map(function (t) {
    return {
      uri: 'deezer:track:' + t.id,
      title: t.title_short || t.title,
      subtitle: t.artist ? t.artist.name : '',
      image: t.album ? (t.album.cover_medium || t.album.cover) : undefined
    };
  });
}

function albumItems(list) {
  return (list || []).filter(function (a) { return a && a.id; }).slice(0, 50).map(function (a) {
    return {
      uri: 'deezer:album:' + a.id,
      title: a.title,
      subtitle: a.artist ? a.artist.name : '',
      image: a.cover_medium || a.cover
    };
  });
}

function artistItems(list) {
  return (list || []).filter(function (a) { return a && a.id; }).slice(0, 50).map(function (a) {
    return {
      uri: 'deezer:artist:' + a.id,
      title: a.name,
      image: a.picture_medium || a.picture
    };
  });
}

function nonEmpty(b) {
  return b.items && b.items.length > 0;
}

myspoti.provide('home', function () {
  var c = getJson(DZ + '/chart/0?limit=30');
  if (!c) return null;
  var tracks = { type: 'tracks', title: de() ? 'Top-Songs' : 'Top songs', items: trackItems(c.tracks && c.tracks.data) };
  var albums = { type: 'albums', title: de() ? 'Beliebte Alben' : 'Popular albums', items: albumItems(c.albums && c.albums.data) };
  var artists = { type: 'artists', title: de() ? 'Beliebte Künstler' : 'Popular artists', items: artistItems(c.artists && c.artists.data) };
  var out = [];
  if (nonEmpty(tracks)) out.push({ type: 'section', title: de() ? 'Charts' : 'Charts', blocks: [tracks] });
  var second = [albums, artists].filter(nonEmpty);
  if (second.length) out.push({ type: 'section', title: de() ? 'Entdecken' : 'Discover', blocks: second });
  return out;
});

myspoti.provide('search', function (input) {
  var q = String((input && input.query) || '').trim();
  if (!q) return null;
  var enc = myspoti.query({ q: q, limit: 20 });
  var res = myspoti.http.all([
    { url: DZ + '/search?' + enc },
    { url: DZ + '/search/album?' + enc },
    { url: DZ + '/search/artist?' + enc }
  ]);
  function data(r) {
    if (!r || r.error || !r.ok) return [];
    try { return r.json().data || []; } catch (e) { return []; }
  }
  var blocks = [
    { type: 'tracks', title: de() ? 'Songs' : 'Songs', items: trackItems(data(res[0])) },
    { type: 'albums', title: de() ? 'Alben' : 'Albums', items: albumItems(data(res[1])) },
    { type: 'artists', title: de() ? 'Künstler' : 'Artists', items: artistItems(data(res[2])) }
  ].filter(nonEmpty);
  return blocks.length ? blocks : null;
});

function firstArtist(track) {
  return norm(track.artist || (track.artists && track.artists[0]) || '');
}

function audiusMatch(track) {
  var j = getJson(AU + '/tracks/search?' + myspoti.query({ query: (track.artist || '') + ' ' + track.title, app_name: APP, limit: 15 }));
  if (!j || !j.data) return null;
  var wantTitle = norm(track.title);
  var wantArtist = firstArtist(track);
  var best = null;
  var bestDelta = 1e12;
  j.data.forEach(function (r) {
    if (!r || r.is_streamable === false || !r.id) return;
    var title = norm(r.title);
    var user = norm(r.user && r.user.name);
    var titleOk = title === wantTitle || (wantTitle.length > 3 && (title.indexOf(wantTitle) === 0 || wantTitle.indexOf(title) === 0));
    var artistOk = wantArtist && (user.indexOf(wantArtist) >= 0 || wantArtist.indexOf(user) >= 0) && user.length > 0;
    if (!titleOk || !artistOk) return;
    var delta = Math.abs((r.duration || 0) * 1000 - (track.durationMs || 0));
    if (track.durationMs && delta > 5000) return;
    if (delta < bestDelta) { best = r; bestDelta = delta; }
  });
  if (!best) return null;
  return {
    url: AU + '/tracks/' + best.id + '/stream?' + myspoti.query({ app_name: APP }),
    mimeType: 'audio/mpeg',
    durationMs: Math.round(best.duration * 1000),
    expiresInMs: 300000,
    codec: 'mp3',
    source: 'Audius'
  };
}

function deezerPreview(track) {
  var j = null;
  if (track.isrc) j = getJson(DZ + '/track/isrc:' + encodeURIComponent(track.isrc));
  if (!j || j.error || !j.preview) {
    var s = getJson(DZ + '/search?' + myspoti.query({ q: 'artist:"' + (track.artist || '') + '" track:"' + track.title + '"', limit: 5 }));
    j = null;
    if (s && s.data) {
      var wantTitle = norm(track.title);
      s.data.forEach(function (t) {
        if (!j && t.preview && norm(t.title_short || t.title).indexOf(wantTitle) >= 0) j = t;
      });
    }
  }
  if (!j || !j.preview) return null;
  return {
    url: j.preview,
    mimeType: 'audio/mpeg',
    durationMs: 30000,
    expiresInMs: 600000,
    codec: 'mp3',
    source: de() ? 'Deezer-Vorschau (30 s)' : 'Deezer preview (30 s)'
  };
}

var SC = 'https://api.soundcloud.com';

function scToken(force) {
  var id = myspoti.settings.get('sc_id');
  var secret = myspoti.settings.get('sc_secret');
  if (!id || !secret) return null;
  var c = myspoti.storage.get('sc_token');
  if (!force && c && c.id === id && c.exp > Date.now() + 60000) return c.token;
  try {
    var r = myspoti.http.post('https://secure.soundcloud.com/oauth/token', 'grant_type=client_credentials', {
      headers: {
        Authorization: 'Basic ' + myspoti.util.base64Encode(id + ':' + secret),
        'Content-Type': 'application/x-www-form-urlencoded',
        accept: 'application/json; charset=utf-8'
      },
      timeout: 8000
    });
    if (!r.ok) return null;
    var j = r.json();
    if (!j.access_token) return null;
    myspoti.storage.set('sc_token', { id: id, token: j.access_token, exp: Date.now() + (j.expires_in || 3600) * 1000 });
    return j.access_token;
  } catch (e) {
    return null;
  }
}

function scRequest(url) {
  var token = scToken(false);
  if (!token) return null;
  var r;
  try {
    r = myspoti.http.get(url, { headers: { Authorization: 'OAuth ' + token, accept: 'application/json; charset=utf-8' }, timeout: 8000 });
    if (r.status === 401) {
      token = scToken(true);
      if (!token) return null;
      r = myspoti.http.get(url, { headers: { Authorization: 'OAuth ' + token, accept: 'application/json; charset=utf-8' }, timeout: 8000 });
    }
  } catch (e) {
    return null;
  }
  return r;
}

function soundcloudMatch(track) {
  var r = scRequest(SC + '/tracks?' + myspoti.query({ q: (track.artist || '') + ' ' + track.title, access: 'playable', limit: 20 }));
  if (!r || !r.ok) return null;
  var list;
  try { list = r.json(); } catch (e) { return null; }
  if (list && list.collection) list = list.collection;
  if (!list || !list.length) return null;
  var wantTitle = norm(track.title);
  var wantArtist = firstArtist(track);
  var best = null;
  var bestDelta = 1e12;
  list.forEach(function (t) {
    if (!t || !t.id || t.streamable === false || (t.access && t.access !== 'playable')) return;
    var title = norm(t.title);
    var user = norm(t.user && (t.user.username || t.user.full_name));
    if (title.indexOf(wantTitle) < 0) return;
    var artistOk = wantArtist && (title.indexOf(wantArtist) >= 0 || (user.length > 0 && (user.indexOf(wantArtist) >= 0 || wantArtist.indexOf(user) >= 0)));
    if (!artistOk) return;
    var delta = Math.abs((t.duration || 0) - (track.durationMs || 0));
    if (track.durationMs && delta > 5000) return;
    if (delta < bestDelta) { best = t; bestDelta = delta; }
  });
  if (!best) return null;
  var s = scRequest(SC + '/tracks/' + best.id + '/stream');
  if (!s) return null;
  var loc = s.headers && s.headers['location'];
  if (!loc || (s.status < 300 || s.status > 399)) return null;
  var out = { url: loc, durationMs: best.duration, expiresInMs: 240000, source: 'SoundCloud' };
  if (loc.indexOf('m3u8') < 0) {
    out.mimeType = 'audio/mpeg';
    out.codec = 'mp3';
  }
  return out;
}

myspoti.provide('audio-source', function (track) {
  var s = soundcloudMatch(track);
  if (s) return s;
  var a = audiusMatch(track);
  if (a) return a;
  if (myspoti.settings.get('preview') !== false) return deezerPreview(track);
  return null;
});
